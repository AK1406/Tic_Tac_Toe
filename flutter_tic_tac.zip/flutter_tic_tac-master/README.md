# Flutter Tic Tac Game 🎮 [![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](http://makeapullrequest.com)

⭐️ this repo if you like it.

## Getting Started 🚀

- Clone the repo
- Install the dependicies
- Run it

## Preview 📸


|                                           |                                           |                                           |
| ----------------------------------------- | ----------------------------------------- | ----------------------------------------- |
| <img src="screenshots/1.jpg" width="400"> | <img src="screenshots/2.jpg" width="400"> | <img src="screenshots/3.jpg" width="400"> |


## Contact me 📧
#### Email : mrbouaggadmoez@gmail.com
#### Website : https://bouaggadmoez.netlify.com/
